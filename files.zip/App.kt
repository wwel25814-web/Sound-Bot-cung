package com.soundboard.overlay

import android.app.Activity
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.abs

private const val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
private const val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

/* =====================================================================
 *  ENGINE: daftar suara, penyimpanan, dan pemutar (overlay = ditumpuk)
 * ===================================================================== */

data class Sound(val id: String, var name: String, val file: String, var loop: Boolean)

object SoundEngine {
    val sounds = mutableListOf<Sound>()
    val listeners = CopyOnWriteArrayList<() -> Unit>()

    var volume = 0.8f
        private set
    var solo = false
        private set

    private val live = HashMap<String, MutableList<MediaPlayer>>()
    private val main = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private val prefs get() = app!!.getSharedPreferences("sb", Context.MODE_PRIVATE)

    fun init(c: Context) {
        if (app != null) return
        app = c.applicationContext
        volume = prefs.getFloat("vol", 0.8f)
        solo = prefs.getBoolean("solo", false)
        try {
            val arr = JSONArray(prefs.getString("list", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                sounds.add(Sound(o.getString("id"), o.getString("name"), o.getString("file"), o.optBoolean("loop")))
            }
        } catch (_: Exception) {
        }
    }

    private fun save() {
        val arr = JSONArray()
        sounds.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("file", it.file).put("loop", it.loop))
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    private fun changed() {
        main.post { listeners.forEach { it() } }
    }

    /** Salin file pilihan pengguna ke penyimpanan aplikasi supaya tetap ada. */
    fun addUris(uris: List<Uri>) {
        val ctx = app ?: return
        Thread {
            val dir = File(ctx.filesDir, "sounds").apply { mkdirs() }
            for (u in uris) {
                try {
                    var name = "Suara"
                    ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (c.moveToFirst() && i >= 0) name = c.getString(i).substringBeforeLast('.')
                    }
                    val id = UUID.randomUUID().toString()
                    val f = File(dir, "$id.snd")
                    ctx.contentResolver.openInputStream(u)?.use { inp -> f.outputStream().use { inp.copyTo(it) } }
                    main.post {
                        sounds.add(Sound(id, name, f.name, false))
                        save()
                        changed()
                    }
                } catch (_: Exception) {
                }
            }
        }.start()
    }

    fun isPlaying(s: Sound) = live[s.id]?.isNotEmpty() == true

    /** Setiap ketukan membuat pemutar baru, jadi suara bisa ditumpuk. */
    fun play(s: Sound) {
        val ctx = app ?: return
        if (solo) stopAll()
        val f = File(ctx.filesDir, "sounds/${s.file}")
        if (!f.exists()) return
        val mp = MediaPlayer()
        live.getOrPut(s.id) { mutableListOf() }.add(mp)
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            mp.isLooping = s.loop
            mp.setVolume(volume, volume)
            mp.setOnPreparedListener { it.start(); changed() }
            mp.setOnCompletionListener { drop(s.id, it) }
            mp.setOnErrorListener { p, _, _ -> drop(s.id, p); true }
            mp.prepareAsync()
        } catch (_: Exception) {
            drop(s.id, mp)
        }
    }

    private fun drop(id: String, mp: MediaPlayer) {
        live[id]?.remove(mp)
        try { mp.release() } catch (_: Exception) {}
        changed()
    }

    fun hit(s: Sound) {
        if (s.loop && isPlaying(s)) stop(s) else play(s)
    }

    fun stop(s: Sound) {
        live[s.id]?.toList()?.forEach { drop(s.id, it) }
    }

    fun stopAll() {
        sounds.forEach { stop(it) }
    }

    fun delete(s: Sound) {
        stop(s)
        app?.let { File(it.filesDir, "sounds/${s.file}").delete() }
        sounds.remove(s)
        save()
        changed()
    }

    fun rename(s: Sound, n: String) {
        if (n.isNotBlank()) s.name = n
        save()
        changed()
    }

    fun setLoop(s: Sound, v: Boolean) {
        s.loop = v
        live[s.id]?.forEach { try { it.isLooping = v } catch (_: Exception) {} }
        save()
        changed()
    }

    fun changeVolume(v: Float) {
        volume = v
        prefs.edit().putFloat("vol", v).apply()
        live.values.forEach { l -> l.forEach { try { it.setVolume(v, v) } catch (_: Exception) {} } }
    }

    fun changeSolo(v: Boolean) {
        solo = v
        prefs.edit().putBoolean("solo", v).apply()
        changed()
    }
}

/* =====================================================================
 *  UI HELPER
 * ===================================================================== */

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun roundRect(fill: Int, radius: Float, stroke: Int = Color.TRANSPARENT, strokeW: Int = 0) =
    GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius
        if (strokeW > 0) setStroke(strokeW, stroke)
    }

fun padColor(i: Int): Int = Color.HSVToColor(floatArrayOf((i * 47f + 255f) % 360f, 0.65f, 0.98f))
fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

fun Context.pill(text: String, accent: Boolean = false, hp: Int = 14, onClick: () -> Unit): TextView =
    TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 13f
        gravity = Gravity.CENTER
        setPadding(dp(hp), dp(10), dp(hp), dp(10))
        background = roundRect(if (accent) 0xFF7C5CFF.toInt() else 0xFF22204A.toInt(), dp(12).toFloat())
        setOnClickListener { onClick() }
    }

fun Context.volumeBar(): SeekBar = SeekBar(this).apply {
    max = 100
    progress = (SoundEngine.volume * 100).toInt()
    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { SoundEngine.changeVolume(p / 100f) }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    })
}

/** Grid pad yang dipakai di aplikasi dan di panel overlay. */
class PadsView(ctx: Context, private val cols: Int, private val onLong: ((Sound) -> Unit)? = null) : ScrollView(ctx) {
    private val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val listener: () -> Unit = { refresh() }

    init {
        isVerticalScrollBarEnabled = false
        addView(box)
        refresh()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        SoundEngine.listeners.add(listener)
        refresh()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        SoundEngine.listeners.remove(listener)
    }

    private fun lp() = LinearLayout.LayoutParams(0, context.dp(88), 1f).apply {
        val m = context.dp(4)
        setMargins(m, m, m, m)
    }

    fun refresh() {
        box.removeAllViews()
        val list = SoundEngine.sounds
        if (list.isEmpty()) {
            box.addView(TextView(context).apply {
                text = "Belum ada suara.\nKetuk + Tambah suara di aplikasi."
                setTextColor(0xFF8D89B5.toInt())
                gravity = Gravity.CENTER
                setPadding(context.dp(16), context.dp(40), context.dp(16), context.dp(40))
            })
            return
        }
        list.chunked(cols).forEachIndexed { r, row ->
            val line = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEachIndexed { c, s -> line.addView(pad(s, r * cols + c), lp()) }
            repeat(cols - row.size) { line.addView(View(context), lp()) }
            box.addView(line)
        }
    }

    private fun pad(s: Sound, i: Int) = TextView(context).apply {
        val col = padColor(i)
        val on = SoundEngine.isPlaying(s)
        text = s.name + if (s.loop) "  ↻" else ""
        setTextColor(Color.WHITE)
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.BOTTOM or Gravity.START
        maxLines = 3
        ellipsize = TextUtils.TruncateAt.END
        setPadding(context.dp(10), context.dp(8), context.dp(10), context.dp(10))
        background = roundRect(
            withAlpha(col, if (on) 0xC0 else 0x38), context.dp(16).toFloat(),
            if (on) Color.WHITE else withAlpha(col, 0xAA), context.dp(2)
        )
        setOnClickListener { SoundEngine.hit(s) }
        setOnLongClickListener { onLong?.invoke(s); onLong != null }
    }
}

/* =====================================================================
 *  LAYAR UTAMA
 * ===================================================================== */

class MainActivity : Activity() {
    private lateinit var modeBtn: TextView
    private lateinit var overlayBtn: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        SoundEngine.init(this)

        val root = LinearLayout(this).apply {
            setBackgroundColor(0xFF0B0A14.toInt())
            fitsSystemWindows = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        root.addView(content, LinearLayout.LayoutParams(MATCH, MATCH))

        content.addView(TextView(this).apply {
            text = "Overlay Soundboard"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFB7A6FF.toInt())
        })
        content.addView(TextView(this).apply {
            text = "Impor suara sendiri, tumpuk beberapa suara, lalu mainkan lewat overlay."
            textSize = 12f
            setTextColor(0xFF8D89B5.toInt())
            setPadding(0, dp(2), 0, dp(10))
        })

        modeBtn = pill("") { SoundEngine.changeSolo(!SoundEngine.solo); updateButtons() }
        overlayBtn = pill("", accent = true) { toggleOverlay() }
        content.addView(row(pill("+ Tambah suara", accent = true) { pickFiles() }, overlayBtn))
        content.addView(row(modeBtn, pill("Stop semua") { SoundEngine.stopAll() }))
        content.addView(volumeBar())
        content.addView(PadsView(this, 3) { showMenu(it) }, LinearLayout.LayoutParams(MATCH, 0, 1f))

        setContentView(root)
        updateButtons()
    }

    override fun onResume() {
        super.onResume()
        updateButtons()
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        v.forEach {
            addView(it, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
        }
    }

    private fun updateButtons() {
        modeBtn.text = if (SoundEngine.solo) "Mode: Solo" else "Mode: Overlay"
        overlayBtn.text = if (OverlayService.running) "Matikan overlay" else "Aktifkan overlay"
    }

    private fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "audio/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(i, 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 1 || res != RESULT_OK || data == null) return
        val list = mutableListOf<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) list.add(clip.getItemAt(i).uri)
        } else {
            data.data?.let { list.add(it) }
        }
        SoundEngine.addUris(list)
    }

    private fun toggleOverlay() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
            window.decorView.postDelayed({ updateButtons() }, 300)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin \"tampil di atas aplikasi lain\", lalu kembali ke sini.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        Toast.makeText(this, "Overlay aktif. Buka aplikasi lain, tombol ♪ akan melayang.", Toast.LENGTH_LONG).show()
        window.decorView.postDelayed({ updateButtons() }, 300)
    }

    private fun showMenu(s: Sound) {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(s.name)
            .setItems(arrayOf("Ganti nama", if (s.loop) "Matikan loop" else "Nyalakan loop", "Hapus")) { _, w ->
                when (w) {
                    0 -> rename(s)
                    1 -> SoundEngine.setLoop(s, !s.loop)
                    2 -> SoundEngine.delete(s)
                }
            }.show()
    }

    private fun rename(s: Sound) {
        val et = EditText(this).apply { setText(s.name); setTextColor(Color.WHITE) }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Ganti nama")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ -> SoundEngine.rename(s, et.text.toString().trim()) }
            .setNegativeButton("Batal", null)
            .show()
    }
}

/* =====================================================================
 *  OVERLAY: tombol ♪ melayang + panel pad di atas aplikasi lain
 * ===================================================================== */

class OverlayService : Service() {
    companion object {
        @Volatile var running = false
        const val STOP = "stop"
        const val CH = "overlay"
    }

    private lateinit var wm: WindowManager
    private lateinit var bubble: TextView
    private lateinit var panel: LinearLayout
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams
    private var panelShown = false

    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f
    private var moved = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        SoundEngine.init(this)
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildBubble()
        buildPanel()
        running = true
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        try { if (panelShown) wm.removeView(panel) } catch (_: Exception) {}
        try { wm.removeView(bubble) } catch (_: Exception) {}
        SoundEngine.stopAll()
        super.onDestroy()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH, "Overlay Soundboard", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else Notification.Builder(this)
        b.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Overlay Soundboard aktif")
            .setContentText("Ketuk untuk membuka aplikasi")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Tutup", stop)
        val n = b.build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, n)
        }
    }

    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun buildBubble() {
        val size = dp(56)
        bubble = TextView(this).apply {
            text = "♪"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF8B6CFF.toInt(), 0xFF22D3C5.toInt())
            ).apply { shape = GradientDrawable.OVAL }
            elevation = dp(6).toFloat()
        }
        bubbleLp = lp(size, size).apply { x = dp(12); y = dp(220) }
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = bubbleLp.x; startY = bubbleLp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (e.rawX - touchX).toInt()
                    val my = (e.rawY - touchY).toInt()
                    if (abs(mx) > dp(6) || abs(my) > dp(6)) moved = true
                    if (moved) {
                        bubbleLp.x = startX + mx
                        bubbleLp.y = startY + my
                        wm.updateViewLayout(bubble, bubbleLp)
                        if (panelShown) placePanel()
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        wm.addView(bubble, bubbleLp)
    }

    private fun buildPanel() {
        val dm = resources.displayMetrics
        val w = minOf(dp(310), dm.widthPixels - dp(16))
        panelLp = lp(w, dp(420))
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect(0xF2141228.toInt(), dp(22).toFloat(), 0xFF2A2750.toInt(), dp(1))
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "Soundboard"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFB7A6FF.toInt())
        }, LinearLayout.LayoutParams(0, WRAP, 1f))

        val modeBtn = pill("", hp = 10) {}
        fun refreshMode() { modeBtn.text = if (SoundEngine.solo) "Solo" else "Overlay" }
        modeBtn.setOnClickListener { SoundEngine.changeSolo(!SoundEngine.solo); refreshMode() }
        refreshMode()

        fun m() = LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(dp(3), 0, 0, 0) }
        head.addView(modeBtn, m())
        head.addView(pill("Stop", hp = 10) { SoundEngine.stopAll() }, m())
        head.addView(pill("✕", hp = 12) { togglePanel() }, m())

        panel.addView(head)
        panel.addView(volumeBar())
        panel.addView(PadsView(this, 3), LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    private fun placePanel() {
        val dm = resources.displayMetrics
        var x = bubbleLp.x
        var y = bubbleLp.y + dp(62)
        if (y + panelLp.height > dm.heightPixels - dp(24)) y = bubbleLp.y - panelLp.height - dp(6)
        x = x.coerceIn(dp(6), (dm.widthPixels - panelLp.width - dp(6)).coerceAtLeast(dp(6)))
        y = y.coerceAtLeast(dp(24))
        panelLp.x = x
        panelLp.y = y
        if (panelShown) wm.updateViewLayout(panel, panelLp)
    }

    private fun togglePanel() {
        if (panelShown) {
            wm.removeView(panel)
            panelShown = false
        } else {
            placePanel()
            wm.addView(panel, panelLp)
            panelShown = true
        }
    }
}
